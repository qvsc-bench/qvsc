# QvsC Max-Cut instance heavyhex-d3-pm1-s2
# heavyhex-d3 topology, random +-1 weights, seed 'heavyhex-d3-pm1-s2'
19 20
1 10 -1
1 14 -1
2 14 1
2 15 -1
3 15 -1
4 10 -1
4 16 1
5 16 -1
5 17 -1
6 13 -1
6 17 1
7 18 1
8 18 -1
8 19 -1
9 13 -1
9 19 -1
11 15 1
11 17 1
12 16 1
12 18 -1
