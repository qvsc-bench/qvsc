# QvsC hardware topology heavyhex-d3 (unit weights; not a benchmark instance)
19 20
1 10 1
1 14 1
2 14 1
2 15 1
3 15 1
4 10 1
4 16 1
5 16 1
5 17 1
6 13 1
6 17 1
7 18 1
8 18 1
8 19 1
9 13 1
9 19 1
11 15 1
11 17 1
12 16 1
12 18 1
